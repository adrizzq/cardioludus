export default function Header() {
  return (
    <div className="flex items-center mb-8">
      <img src="/logo.svg" alt="Logo Cardio Ludus" className="h-12 mr-4" />
      <div className="text-sm">
        <div className="font-bold text-blue-900">LUDUS</div>
        <div className="text-gray-500">cardiovascular simulator</div>
      </div>
    </div>
  );
}