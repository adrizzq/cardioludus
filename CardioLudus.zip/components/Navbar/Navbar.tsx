export default function Navbar() {
  return (
    <div className="flex space-x-6 text-sm uppercase font-medium text-gray-600 mt-4">
      <span className="text-blue-900 font-bold border-b-2 border-blue-900 pb-1">Início</span>
      <span>Simulador</span>
      <span>Contato</span>
    </div>
  );
}