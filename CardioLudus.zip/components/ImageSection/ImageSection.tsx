export default function ImageSection() {
  return (
    <div className="md:w-1/2 mt-10 md:mt-0 flex flex-col items-end relative">
      <div className="absolute top-0 right-0 flex space-x-4 mt-2 mr-2">
        <button className="border-2 border-red-700 text-red-700 px-4 py-1 rounded-full text-sm font-semibold">
          CRIAR CONTA
        </button>
        <button className="bg-red-700 text-white px-6 py-1 rounded-full text-sm font-semibold">
          LOGIN
        </button>
      </div>
      <img
        src="/modelo-cardiaco.jpg"
        alt="Modelo cardíaco"
        className="w-full max-w-lg rounded-md shadow-md mt-12"
      />
    </div>
  );
}