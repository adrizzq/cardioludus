export default function Hero() {
  return (
    <div className="mb-6">
      <h1 className="text-2xl md:text-4xl font-medium leading-snug">
        BEM VINDO AO <br />
        <span className="text-red-700 font-bold">CARDIO </span>
        <span className="text-blue-900 font-bold">LUDUS</span>
      </h1>
      <p className="mt-4 text-gray-600 max-w-md">
        Plataforma de simulação da fisiologia e das patologias do sistema cardiovascular.
      </p>
    </div>
  );
}