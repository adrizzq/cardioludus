import Header from "@/components/Header/Header";
import Hero from "@/components/Hero/Hero";
import Navbar from "@/components/Navbar/Navbar";
import ImageSection from "@/components/ImageSection/ImageSection";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white flex flex-col md:flex-row p-6 md:p-12 font-sans">
      <div className="md:w-1/2 flex flex-col justify-between">
        <Header />
        <Hero />
        <Navbar />
      </div>
      <ImageSection />
    </div>
  );
}