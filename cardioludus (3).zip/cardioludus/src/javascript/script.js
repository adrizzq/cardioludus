 function toggleMenu() {
    const sidebar = document.getElementById('sidebar');
    const perfil = document.getElementById('perfil-info');

    sidebar.classList.toggle('active');

    // Fecha o perfil se o menu for fechado
    if (!sidebar.classList.contains('active') && perfil.classList.contains('show')) {
      perfil.classList.remove('show');
    }
  }

  function togglePerfil() {
    const perfil = document.getElementById('perfil-info');
    perfil.classList.toggle('show');
  }

  // Fecha o perfil se clicar fora dele
  document.addEventListener('click', function(event) {
    const perfil = document.getElementById('perfil-info');
    const isPerfilOpen = perfil.classList.contains('show');

    const sidebar = document.getElementById('sidebar');
    const clickedInsideSidebar = sidebar.contains(event.target);
    const clickedInsidePerfil = perfil.contains(event.target);

    if (isPerfilOpen && !clickedInsidePerfil && !clickedInsideSidebar) {
      perfil.classList.remove('show');
    }
  });

